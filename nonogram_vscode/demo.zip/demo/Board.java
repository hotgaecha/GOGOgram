public class Board {
    private int[][] grid;
    private int size;

    public Board(int size) {
        this.size = size;
        this.grid = new int[size][size];
    }

    // Getter 메서드
    public int[][] getGrid() {
        return grid;
    }

    public int getSize() {
        return size;
    }

    // Setter 메서드
    public void setGrid(int[][] grid) {
        this.grid = grid;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
