@RestController //클래스가 REST 컨트롤러임을 선언
@RequestMapping("/api/game") //이 경로에 대한 처리는 이 컨트롤러가 담당
public class GameController {
    
    @Autowired //의존성 주입(자동으로 객체 생성 및 주입)
    private GameService gameService;

    @PostMapping("/start")//POST 방식으로 /api/game/start 경로에 요청이 오면 이 메서드가 처리
    public ResponseEntity<GameState> startGame(@RequestParam int size) 
    {
        GameState gameState = gameService.startNewGame(size);
        return ResponseEntity.ok(gameState);
    }

    // 다른 API 엔드포인트들에 대한 메서드들...
}
