public class GameService { //게임의 진행에 대한 로직

    //멤버 변수 선언 ( 객체 생성 )
    private GogogramValidator validator;
    private Board board;
    private GameState gameState;

    //생성자... 새로운 게임 시작시 -> 객체 초기화 
    public GameService(int boardSize) {
        this.validator = new GogogramValidator();
        this.board = new Board(boardSize);
        this.gameState = new GameState(board);
    }

    //새 게임 시작시 호출되는 메서드, 초기화 작업만 수행함.
    public void startNewGame(int boardSize) {
        this.board = new Board(boardSize);
        this.gameState = new GameState(board);
    }

    //사용자가 선택한 위치에 값을 채우는 메서드
    public boolean makeMove(int row, int col, int value) {
        if (!validator.isValidMove(board, row, col, value)) //검증로직을 사용함
        {
            return false;
        }
        board.setValue(row, col, value);
        // 게임 승리 여부 확인 로직 등...
        return true;
    }

    // 다른 게임 진행 관련 메서드들...
}
