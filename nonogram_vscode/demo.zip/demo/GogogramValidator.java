public class GogogramValidator {  //Gogogram 검증 로직
    //사용자가 선택한 위치가 유효한지를 검사하는 메서드
    public boolean isValidMove(Board board, int row, int col, int value) {
        // 특정 위치에 이미 값이 채워져 있는지 확인
        if (board.getGrid()[row][col] != 0) // 0이 아니면 이미 값이 채워져 있음 
        {
            return false;
        }
        
        // 행에 중복된 숫자가 있는지 확인
        for (int i = 0; i < board.getSize(); i++) {
            if (board.getGrid()[i][col] == value) {
                return false;
            }
        }
        
        // 열에 중복된 숫자가 있는지 확인
        for (int j = 0; j < board.getSize(); j++) {
            if (board.getGrid()[row][j] == value) {
                return false;
            }
        }
        
        // 특정 영역 안에 중복된 숫자가 있는지 확인
        // (예를 들어, 3x3 영역)
        int startRow = row / 3 * 3;
        int startCol = col / 3 * 3;
        for (int i = startRow; i < startRow + 3; i++) {
            for (int j = startCol; j < startCol + 3; j++) {
                if (board.getGrid()[i][j] == value) {
                    return false;
                }
            }
        }
        
        return true;
    }
}
