public class gogogram {
    private int[][] rowHints;
    private int[][] colHints;
    private int[][] solution;


    public gogogram(int[][] rowHints, int[][] colHints, int[][] solution) {
        this.rowHints = rowHints;
        this.colHints = colHints;
        this.solution = solution;
    }
    public int[][] getRowHints() {
        return rowHints;
    }
    public void setRowHints(int[][] rowHints) {
        this.rowHints = rowHints;
    }

    


    public int[][] getColHints() {
        return colHints;
    }
    public void setColHints(int[][] colHints) {
        this.colHints = colHints;
    }
    

    
    public int[][] getSolution() {
        return solution;
    }
    public void setSolution(int[][] solution) {
        this.solution = solution;
    }
    
    // Constructor, Getter, Setter 메서드 등...
    
}