public class gogogramProgress {
    private int[][] userGrid;
    private boolean isCompleted;
    
    
    // Constructor, Getter, Setter 메서드 등...
    
    public gogogramProgress(int[][] userGrid, boolean isCompleted) {
        this.userGrid = userGrid;
        this.isCompleted = isCompleted;
    }


    public boolean checkCompletion(int[][] solution) {
        // 사용자의 입력과 정답을 비교하여 게임 종료 여부를 판단하는 로직
    }


    public int[][] getUserGrid() {
        return userGrid;
    }


    public void setUserGrid(int[][] userGrid) {
        this.userGrid = userGrid;
    }


    public boolean isCompleted() {
        return isCompleted;
    }


    public void setCompleted(boolean isCompleted) {
        this.isCompleted = isCompleted;
    }
}